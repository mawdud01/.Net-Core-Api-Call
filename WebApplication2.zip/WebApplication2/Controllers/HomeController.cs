﻿using System;
using System.Collections.Generic;
using System.Net.Http;
using System.Text.Json;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;

public class HomeController : Controller
{
    public async Task<IActionResult> Index()
    {
        using var httpClient = new HttpClient();
        var apiUrl = "https://www.pqstec.com/InvoiceApps/values/GetProductListAll";

        try
        {
            var response = await httpClient.GetStringAsync(apiUrl);
            var products = JsonSerializer.Deserialize<List<Product>>(response);
            return View(products);
        }
        catch (Exception ex)
        {
            ViewBag.ErrorMessage = $"An error occurred: {ex.Message}";
            return View(new List<Product>());
        }
    }
}

public class Product
{
    public int Id { get; set; }
    public string CategoryName { get; set; }
    public string Name { get; set; }
    public decimal Price { get; set; }
}
